Luncher
===============================
Backend application for Luncher.


author: Piotr Poteralski

Overview
--------

The application was created for recruitation purposes

Requirements
------------

https://docs.docker.com/engine/installation/


Usage
-----
To run test you should build project using docker-compose command:

```
docker-compose build
```

Then to run test you simply use up parameter

```
docker-compose up
```

You should see log with test errors.
See issues for all task list.

Good Luck!
