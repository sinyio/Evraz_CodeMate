from datetime import datetime

from flask import current_app
from itsdangerous import TimestampSigner

# TODO: отсутсвуют типы данных, в возвращаемых функциях указаны частично
class TokenHelper:
    def __init__(self) -> None:
        # TODO: инстанцирование TimestampSigner дальше не используем
        self.serializer = TimestampSigner(current_app.config.SECRET_KEY)

    def create(self, user_id):
        s = TimestampSigner(current_app.config.SECRET_KEY)
        return s.sign({
            "datetime": datetime.now(),
            "user_id": user_id
        })
