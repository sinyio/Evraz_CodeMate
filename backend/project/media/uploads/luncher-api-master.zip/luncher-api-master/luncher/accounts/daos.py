from luncher.accounts.models import User
from luncher.database import BaseDao

# TODO: Наследует полный CRUD от базового класса, отсутсвует интерфейс
# TODO: По стандарту используем DI
class UserDao(BaseDao):
    def __init__(self):
        super().__init__(User)
