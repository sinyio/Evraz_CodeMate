from luncher.extensions import db
from utils.sqla.models import SurrogatePK

from sqlalchemy import Column, ForeignKey, Integer, Table, String

# TODO: Таблицы описаны в виде классов декларативный стиль, по стандарту в виде обычных таблиц
class User(db.Model, SurrogatePK):
    """Dummy user model"""
    __tablename__ = 'users'

    login = Column(String, nullable=False)
    password = Column(String, nullable=False)
