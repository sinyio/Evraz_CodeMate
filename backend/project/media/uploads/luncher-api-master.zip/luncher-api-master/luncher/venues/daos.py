from luncher.database import BaseDao
from luncher.meals.models import Venue

# TODO: Наследует полный CRUD от базового класса, отсутсвует интерфейс
class VenueDao(BaseDao):
    def __init__(self):
        super().__init__(Venue)
