from luncher.database import BaseDao
from luncher.meals.models import Meal

# TODO: Наследует полный CRUD от базового класса, отсутсвует интерфейс
class MealDao(BaseDao):
    def __init__(self):
        super().__init__(Meal)
