class ContentType:
    MULTIPART_FORM_DATA = 'multipart/form-data'
    APPLICATION_JSON = 'application/json'
# TODO: Не похоже на utils